from scylla import cli
from ._version import __version__

__author__ = 'WildCat'
__copyright__ = 'Copyright 2018, WildCat'
