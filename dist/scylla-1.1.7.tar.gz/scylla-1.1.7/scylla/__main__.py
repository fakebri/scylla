from scylla.cli import app_main


app_main()
